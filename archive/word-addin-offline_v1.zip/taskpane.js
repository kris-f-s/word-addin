/* global Office */

// 添加错误处理和诊断信息
console.log('taskpane.js 开始加载...');

// 无论 Office.js 是否加载，都尝试初始化基本功能（用于浏览器测试）
// 这样在浏览器中也能测试界面和基本功能

// 等待 DOM 加载完成后初始化
function initWhenReady() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            console.log('✓ DOMContentLoaded 事件触发');
            initializeAddIn();
        });
    } else {
        console.log('✓ DOM 已就绪，直接初始化');
        initializeAddIn();
    }
}

// 无论 Office.js 是否加载，都确保初始化执行
// 先尝试初始化（不等待 Office.js）
if (document.readyState === 'loading') {
    // DOM 还在加载，等待加载完成
    document.addEventListener('DOMContentLoaded', () => {
        console.log('✓ DOMContentLoaded 事件触发（无 Office.js）');
        initializeAddIn();
    });
} else {
    // DOM 已就绪，立即初始化
    console.log('✓ DOM 已就绪，立即初始化（无 Office.js）');
    // 使用 setTimeout 确保在下一个事件循环中执行，避免与 Office.js 检查冲突
    setTimeout(() => {
        initializeAddIn();
    }, 0);
}

// 检查 Office.js 是否加载
if (typeof Office === 'undefined') {
    console.warn('⚠️ Office.js 未加载（在浏览器中测试时这是正常的）');
    
    // 显示友好的提示信息（但不阻止初始化）
    const showInfo = () => {
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = 'padding: 15px; color: #8a5000; background: #fff4e5; border: 1px solid #ffaa44; border-radius: 4px; margin: 20px;';
        errorDiv.innerHTML = `
            <strong>ℹ️ 提示：</strong>此页面在浏览器中打开时，Office.js 功能不可用。
            但你可以测试界面和基本功能（添加/删除规则行）。
            <br><br>
            <small>要在 Word 中使用完整功能，请在 Word 中加载插件。</small>
        `;
        
        if (document.body) {
            document.body.insertBefore(errorDiv, document.body.firstChild);
        }
    };
    
    if (document.body) {
        showInfo();
    } else {
        document.addEventListener('DOMContentLoaded', showInfo);
    }
} else {
    console.log('✓ Office.js 已加载');
    
    Office.onReady((info) => {
        console.log('✓ Office.onReady 回调执行');
        console.log('  - Host:', info.host);
        console.log('  - Platform:', info.platform);
        
        if (info.host === Office.HostType.Word) {
            console.log('✓ 检测到 Word 环境');
            // 在 Word 环境中，如果还没初始化，则初始化
            // 使用 setTimeout 避免重复初始化
            setTimeout(() => {
                const container = document.getElementById('rules-container');
                if (!container || container.children.length === 0) {
                    console.log('在 Word 环境中执行初始化...');
                    initWhenReady();
                } else {
                    console.log('已在浏览器中初始化，跳过 Word 环境初始化');
                }
            }, 100);
        } else {
            console.warn('⚠️ 警告: 不在 Word 环境中，Host:', info.host);
            
            // 显示警告信息
            const warningDiv = document.createElement('div');
            warningDiv.style.cssText = 'padding: 15px; color: #8a5000; background: #fff4e5; border: 1px solid #ffaa44; border-radius: 4px; margin: 20px;';
            warningDiv.innerHTML = `
                <strong>⚠️ 警告：</strong>此插件需要在 Microsoft Word 中运行。
                当前环境：${info.host}。
            `;
            
            if (document.body) {
                document.body.insertBefore(warningDiv, document.body.firstChild);
            }
        }
    }).catch((error) => {
        console.error('✗ Office.onReady 错误:', error);
        
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = 'padding: 20px; color: #d13438; background: #fef6f6; border: 1px solid #d13438; border-radius: 4px; margin: 20px;';
        errorDiv.innerHTML = `
            <h2 style="margin-top: 0;">✗ Office.js 初始化失败</h2>
            <p><strong>错误信息：</strong> ${error.message || error}</p>
            <p>请查看浏览器控制台获取详细信息。</p>
        `;
        
        if (document.body) {
            document.body.insertBefore(errorDiv, document.body.firstChild);
        }
    });
}

let ruleCounter = 0;

// 防止重复初始化
let isInitialized = false;

function initializeAddIn() {
    // 防止重复初始化
    if (isInitialized) {
        console.log('⚠️ 插件已初始化，跳过重复初始化');
        return;
    }
    
    console.log('开始初始化插件...');
    
    try {
        // 检查必要的元素是否存在
        const addRuleBtn = document.getElementById('add-rule-btn');
        const confirmBtn = document.getElementById('confirm-btn');
        const cancelBtn = document.getElementById('cancel-btn');
        const container = document.getElementById('rules-container');
        
        if (!addRuleBtn) {
            throw new Error('找不到"添加规则"按钮 (id: add-rule-btn)');
        }
        if (!confirmBtn) {
            throw new Error('找不到"确认"按钮 (id: confirm-btn)');
        }
        if (!cancelBtn) {
            throw new Error('找不到"取消"按钮 (id: cancel-btn)');
        }
        if (!container) {
            throw new Error('找不到规则容器 (id: rules-container)');
        }
        
        // 添加第一行规则（如果还没有）
        if (container.children.length === 0) {
            addRuleRow();
            console.log('✓ 添加了第一行规则');
        } else {
            console.log('✓ 规则已存在，跳过添加');
        }
        
        // 绑定事件（先移除可能存在的旧监听器，避免重复绑定）
        const newAddHandler = () => {
            console.log('点击了"添加规则"按钮');
            addRuleRow();
        };
        
        // 移除旧的事件监听器（如果存在）
        addRuleBtn.replaceWith(addRuleBtn.cloneNode(true));
        const newAddBtn = document.getElementById('add-rule-btn');
        newAddBtn.addEventListener('click', newAddHandler);
        console.log('✓ 绑定了"添加规则"按钮事件');
        
        const newConfirmHandler = () => {
            console.log('点击了"确认"按钮');
            applyFormatting();
        };
        
        confirmBtn.replaceWith(confirmBtn.cloneNode(true));
        const newConfirmBtn = document.getElementById('confirm-btn');
        newConfirmBtn.addEventListener('click', newConfirmHandler);
        console.log('✓ 绑定了"确认"按钮事件');
        
        const newCancelHandler = () => {
            console.log('点击了"取消"按钮');
            // 清空所有规则
            const container = document.getElementById('rules-container');
            container.innerHTML = '';
            ruleCounter = 0;
            addRuleRow();
        };
        
        cancelBtn.replaceWith(cancelBtn.cloneNode(true));
        const newCancelBtn = document.getElementById('cancel-btn');
        newCancelBtn.addEventListener('click', newCancelHandler);
        console.log('✓ 绑定了"取消"按钮事件');
        
        // 监听快捷键 Shift+Alt+O+P
        // Mac 键盘对应：Shift + Option + O，然后按 P
        // 注意：Office Add-in 的快捷键支持有限，需要在任务窗格获得焦点时才能工作
        // 如果需要全局快捷键，建议使用 macOS 的全局快捷键工具（如 Keyboard Maestro）
        let waitingForP = false;
        let timeoutId = null;
        
        document.addEventListener('keydown', (e) => {
            // 检测 Shift + Option (Alt) + O
            // Mac 上 altKey 对应 Option 键
            if (e.shiftKey && e.altKey) {
                const key = e.key.toLowerCase();
                
                if (key === 'o' && !waitingForP) {
                    // 按下 O，等待 P
                    waitingForP = true;
                    e.preventDefault();
                    
                    // 清除之前的超时
                    if (timeoutId) {
                        clearTimeout(timeoutId);
                    }
                    
                    // 设置超时，如果 2 秒内没有按 P，重置状态
                    timeoutId = setTimeout(() => {
                        waitingForP = false;
                        timeoutId = null;
                    }, 2000);
                    
                    // 监听下一个按键
                    const pKeyHandler = (e2) => {
                        const key2 = e2.key.toLowerCase();
                        
                        if (key2 === 'p' && waitingForP) {
                            // 成功触发快捷键
                            e2.preventDefault();
                            waitingForP = false;
                            
                            // 清除超时
                            if (timeoutId) {
                                clearTimeout(timeoutId);
                                timeoutId = null;
                            }
                            
                            // 确保任务窗格获得焦点
                            window.focus();
                            
                            // 滚动到顶部（可选）
                            document.body.scrollTop = 0;
                            document.documentElement.scrollTop = 0;
                            
                            console.log('✓ 快捷键 Shift+Option+O+P 已触发');
                        }
                    };
                    
                    // 使用 once: true 自动移除监听器
                    document.addEventListener('keydown', pKeyHandler, { once: true });
                }
            }
            
            // 如果按了其他键（不是 Shift+Option+P），重置状态
            if (waitingForP && !(e.shiftKey && e.altKey)) {
                const key = e.key.toLowerCase();
                if (key !== 'p') {
                    waitingForP = false;
                    if (timeoutId) {
                        clearTimeout(timeoutId);
                        timeoutId = null;
                    }
                }
            }
        });
        console.log('✓ 快捷键监听器已设置');
        
        // 标记为已初始化
        isInitialized = true;
        console.log('✓ 插件初始化完成！');
        
    } catch (error) {
        console.error('✗ 初始化错误:', error);
        
        const errorDiv = document.createElement('div');
        errorDiv.style.cssText = 'padding: 20px; color: #d13438; background: #fef6f6; border: 1px solid #d13438; border-radius: 4px; margin: 20px;';
        errorDiv.innerHTML = `
            <h2 style="margin-top: 0;">✗ 初始化失败</h2>
            <p><strong>错误：</strong> ${error.message}</p>
            <p>请查看浏览器控制台获取详细信息。</p>
        `;
        
        if (document.body) {
            document.body.insertBefore(errorDiv, document.body.firstChild);
        }
    }
}

function addRuleRow() {
    const container = document.getElementById('rules-container');
    if (!container) {
        console.error('找不到 rules-container 元素');
        return;
    }
    
    const ruleId = `rule-${ruleCounter++}`;
    
    const ruleRow = document.createElement('div');
    ruleRow.className = 'rule-row';
    ruleRow.id = ruleId;
    
    ruleRow.innerHTML = `
        <div class="input-group" style="flex: 2;">
            <label>搜索文本</label>
            <input type="text" class="search-text" placeholder="输入要搜索的文本" />
        </div>
        <div class="color-group">
            <label>字体颜色</label>
            <input type="color" class="font-color" value="#000000" />
        </div>
        <div class="color-group">
            <label>背景颜色</label>
            <input type="color" class="bg-color" value="#ffffff" />
        </div>
        <button class="add-btn" onclick="addRuleRow()">+</button>
        <button class="remove-btn" onclick="removeRuleRow('${ruleId}')">×</button>
    `;
    
    container.appendChild(ruleRow);
    console.log(`✓ 添加了规则行: ${ruleId}`);
}

// 全局函数，供 HTML 中的 onclick 调用
window.addRuleRow = addRuleRow;

function removeRuleRow(ruleId) {
    const ruleRow = document.getElementById(ruleId);
    if (ruleRow) {
        ruleRow.remove();
        console.log(`✓ 删除了规则行: ${ruleId}`);
    }
    
    // 如果删除后没有规则了，添加一个默认规则
    const container = document.getElementById('rules-container');
    if (container && container.children.length === 0) {
        addRuleRow();
    }
}

window.removeRuleRow = removeRuleRow;

async function applyFormatting() {
    console.log('开始应用格式化...');
    
    try {
        const rules = collectRules();
        console.log('收集到的规则:', rules);
        
        if (rules.length === 0) {
            alert('请至少添加一条规则');
            return;
        }
        
        // 检查 Office.js 是否可用
        if (typeof Office === 'undefined' || typeof Word === 'undefined') {
            alert('错误: Office.js 未加载。请在 Word 中使用此插件。');
            return;
        }
        
        // 显示加载状态
        const confirmBtn = document.getElementById('confirm-btn');
        const originalText = confirmBtn.querySelector('.ms-Button-label').textContent;
        confirmBtn.querySelector('.ms-Button-label').textContent = '处理中...';
        confirmBtn.disabled = true;
        
        await Word.run(async (context) => {
            const body = context.document.body;
            body.load('text');
            
            await context.sync();
            
            // 对每个规则进行处理
            for (const rule of rules) {
                if (!rule.searchText || rule.searchText.trim() === '') {
                    continue;
                }
                
                console.log(`处理规则: 搜索 "${rule.searchText}"`);
                
                // 搜索所有匹配的文本
                const searchResults = body.search(rule.searchText, {
                    matchCase: false,
                    matchWholeWord: false,
                    matchWildcards: false
                });
                
                context.load(searchResults, 'items');
                await context.sync();
                
                console.log(`找到 ${searchResults.items.length} 个匹配结果`);
                
                // 对每个匹配结果应用格式
                searchResults.items.forEach((range) => {
                    range.font.color = rule.fontColor;
                    range.font.highlightColor = rule.bgColor;
                });
            }
            
            await context.sync();
        });
        
        // 恢复按钮状态
        confirmBtn.querySelector('.ms-Button-label').textContent = originalText;
        confirmBtn.disabled = false;
        
        // 显示成功消息
        alert('格式应用成功！');
        console.log('✓ 格式化应用成功');
        
    } catch (error) {
        console.error('✗ 应用格式化时出错:', error);
        
        const confirmBtn = document.getElementById('confirm-btn');
        if (confirmBtn) {
            confirmBtn.querySelector('.ms-Button-label').textContent = '确认';
            confirmBtn.disabled = false;
        }
        
        alert('错误: ' + error.message);
    }
}

function collectRules() {
    const rules = [];
    const ruleRows = document.querySelectorAll('.rule-row');
    
    ruleRows.forEach((row) => {
        const searchTextInput = row.querySelector('.search-text');
        const fontColorInput = row.querySelector('.font-color');
        const bgColorInput = row.querySelector('.bg-color');
        
        if (searchTextInput && fontColorInput && bgColorInput) {
            const searchText = searchTextInput.value.trim();
            const fontColor = fontColorInput.value;
            const bgColor = bgColorInput.value;
            
            if (searchText) {
                rules.push({
                    searchText: searchText,
                    fontColor: fontColor,
                    bgColor: bgColor
                });
            }
        }
    });
    
    return rules;
}
